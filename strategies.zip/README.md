# ⚡ Energy Trading Strategies — Power & Gas

> A comprehensive, open-source reference portfolio covering quantitative and discretionary trading strategies applied to European and global Power & Gas markets.

---

## Overview

This repository collects, implements, and documents **all major trading strategy families** used in wholesale energy markets — from fundamental spread trading to advanced statistical arbitrage and algorithmic execution. Each strategy module includes:

- Conceptual description and market rationale
- Python implementation (backtestable)
- Key parameters and risk metrics
- Historical performance notes
- References and further reading

---

## Repository Structure

```
energy-trading-strategies/
│
├── README.md
├── requirements.txt
├── config/
│   └── market_config.yaml          # Hub definitions, contract specs
│
├── 01_spread_trading/
│   ├── spark_spread.py             # Gas → Power spread
│   ├── dark_spread.py              # Coal → Power spread
│   ├── clean_spark_spread.py       # Spark spread net of EUA cost
│   ├── clean_dark_spread.py        # Dark spread net of EUA cost
│   └── README.md
│
├── 02_calendar_spreads/
│   ├── prompt_vs_forward.py        # DA vs Month-ahead
│   ├── winter_summer_spread.py     # Seasonal strip spread
│   ├── quarterly_roll.py           # Q rolling strategy
│   └── README.md
│
├── 03_geographic_arbitrage/
│   ├── cross_border_power.py       # Interconnector arb (e.g. FR-DE, IT-AT)
│   ├── ttf_ncp_spread.py           # TTF vs NCG/NCGas
│   ├── nbp_ttf_spread.py           # UK vs Continental gas
│   └── README.md
│
├── 04_fundamental_strategies/
│   ├── supply_demand_model.py      # Net load forecasting-driven
│   ├── merit_order_model.py        # Stack-based price model
│   ├── storage_valuation.py        # Seasonal gas storage optionality
│   ├── hydro_premium.py            # Hydro reservoir level signal
│   └── README.md
│
├── 05_statistical_arbitrage/
│   ├── cointegration_pairs.py      # EG/Johansen cointegration
│   ├── ou_mean_reversion.py        # Ornstein-Uhlenbeck process
│   ├── kalman_spread_filter.py     # Dynamic hedge ratio
│   └── README.md
│
├── 06_volatility_strategies/
│   ├── vol_surface_model.py        # Implied vol surface fitting
│   ├── straddle_strangle.py        # Options vol plays
│   ├── swing_option_valuation.py   # Take-or-pay optionality
│   └── README.md
│
├── 07_intraday_strategies/
│   ├── id_auction_strategy.py      # EPEX/GME intraday auction
│   ├── continuous_id_mm.py         # Intraday continuous market making
│   ├── imbalance_signal.py         # TSO imbalance price signal
│   └── README.md
│
├── 08_algorithmic_execution/
│   ├── twap_execution.py           # Time-weighted average price
│   ├── vwap_execution.py           # Volume-weighted (shape-based)
│   ├── optimal_slice.py            # Almgren-Chriss style
│   └── README.md
│
├── 09_machine_learning/
│   ├── lstm_price_forecast.py      # LSTM for DA price prediction
│   ├── xgb_spread_signal.py        # XGBoost for spread classification
│   ├── regime_detection.py         # HMM market regime classification
│   └── README.md
│
├── 10_risk_management/
│   ├── var_cvar.py                 # Value at Risk / CVaR
│   ├── position_limits.py          # Delta/gamma limits framework
│   ├── hedge_effectiveness.py      # IAS 39 hedge effectiveness test
│   └── README.md
│
├── notebooks/
│   ├── 01_spark_spread_analysis.ipynb
│   ├── 02_ttf_cointegration.ipynb
│   ├── 03_intraday_patterns.ipynb
│   └── 04_storage_optionality.ipynb
│
└── data/
    ├── sample_power_prices.csv
    ├── sample_gas_prices.csv
    └── sample_eua_prices.csv
```

---

## Strategy Families at a Glance

### 1. Spread Trading
The backbone of power & gas trading. Exploiting the relationship between fuel input costs and power output prices.

| Strategy | Markets | Key Driver |
|---|---|---|
| Spark Spread | Gas + Power | Gas-fired margin |
| Dark Spread | Coal + Power | Coal-fired margin |
| Clean Spark/Dark | Gas/Coal + Power + EUA | Carbon-adjusted margin |

### 2. Calendar Spreads
Exploiting seasonal and structural time-premium differences across contract tenors.

| Strategy | Markets | Key Driver |
|---|---|---|
| Prompt vs Forward | DA vs M+1 | Time value / risk premium |
| Winter/Summer | Cal strips | Seasonality |
| Quarterly Roll | Q contracts | Forward curve shape |

### 3. Geographic Arbitrage
Cross-border price differentials limited by interconnector capacity.

| Strategy | Markets | Key Driver |
|---|---|---|
| Interconnector Arb | FR-DE, IT-AT, UK-FR | Congestion / NTC |
| TTF-NCG | Dutch vs German gas | Hub premium |
| NBP-TTF | UK vs Continental | LNG / storage |

### 4. Fundamental Trading
Model-driven directional positions based on supply/demand balance analysis.

- **Net load forecasting**: renewable penetration, temperature, industrial load
- **Merit order modelling**: marginal cost stack, dispatch simulation
- **Storage optionality**: seasonal gas storage intrinsic & extrinsic value

### 5. Statistical Arbitrage
Quantitative mean-reversion exploiting temporary mispricings.

- Cointegration-based pairs trading (Engle-Granger, Johansen)
- Ornstein-Uhlenbeck parameter estimation
- Kalman filter for dynamic hedge ratio

### 6. Volatility Strategies
Exploiting implied vs realised vol differences in energy options markets.

- Implied volatility surface modelling
- Straddle/strangle strategies on power & gas options
- Swing option valuation (intrinsic + extrinsic decomposition)

### 7. Intraday Strategies
Short-term alpha from intraday market microstructure.

- EPEX SPOT / GME intraday auction participation
- Continuous intraday market making
- Imbalance settlement price signal trading

### 8. Algorithmic Execution
Execution frameworks to minimise market impact and slippage.

- TWAP / VWAP for energy shape profiles
- Optimal execution (Almgren-Chriss adapted for energy)

### 9. Machine Learning
Data-driven price and signal modelling.

- LSTM neural networks for DA price forecasting
- XGBoost classifier for spread signal generation
- Hidden Markov Model for market regime detection (contango / backwardation / volatile)

### 10. Risk Management
Portfolio-level risk monitoring and hedging frameworks.

- Value at Risk & Conditional VaR for energy portfolios
- Greek limits for options books
- Hedge effectiveness testing

---

## Key Concepts

### Spark Spread Formula
```
Spark Spread = Power Price − (Gas Price / Efficiency Factor)
Clean Spark Spread = Spark Spread − (EUA Price × Emission Factor)
```

### Typical Efficiency Factors
| Plant Type | Efficiency | CO₂ Factor (t/MWh) |
|---|---|---|
| CCGT | 0.49–0.52 | 0.35–0.40 |
| OCGT | 0.35–0.42 | 0.50–0.55 |
| Coal | 0.35–0.40 | 0.85–0.95 |

---

## Data Sources

| Source | Type | Notes |
|---|---|---|
| ENTSO-E Transparency | Power prices, flows, generation | Free API |
| AGSI+ (GIE) | Gas storage levels | Free API |
| EEX / ICE | Futures prices | Commercial |
| Refinitiv / LSEG | Historical prices | Commercial |
| Open Power System Data | Academic datasets | Free |

---

## Getting Started

```bash
git clone https://github.com/yourusername/energy-trading-strategies
cd energy-trading-strategies
pip install -r requirements.txt
jupyter notebook notebooks/01_spark_spread_analysis.ipynb
```

---

## Requirements

```
pandas>=2.0
numpy>=1.24
scipy>=1.10
statsmodels>=0.14
scikit-learn>=1.3
xgboost>=1.7
tensorflow>=2.12
matplotlib>=3.7
plotly>=5.14
entsoe-py>=0.5
```

---

## Roadmap

- [ ] Add live ENTSO-E data pipeline
- [ ] Backtesting engine with realistic transaction costs
- [ ] Italian GME market module
- [ ] LNG arbitrage (JKM-TTF-HH)
- [ ] Battery storage dispatch optimisation
- [ ] Power PPA pricing model

---

## Contributing

Pull requests welcome. Please open an issue first to discuss major changes.

---

## Disclaimer

This repository is for **educational and research purposes only**. Nothing here constitutes financial advice or a recommendation to trade. Energy markets carry significant risk.

---

## License

MIT License — see [LICENSE](LICENSE) for details.

---

*Built for quantitative energy traders, analysts, and researchers.*
